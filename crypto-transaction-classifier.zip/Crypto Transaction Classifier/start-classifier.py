#!/usr/bin/env python3
"""Local helper for the Crypto Transaction Classifier.

Serves evm-tx-classifier.html at http://127.0.0.1:8765 and forwards a few API requests that
browsers are not allowed to make directly:

    /proxy/api.blockscout.com/...   Blockscout PRO multichain API (needs your Blockscout key)
    /proxy/btc1.trezor.io/...       Trezor Blockbook (Bitcoin xpub / ypub / zpub)
    /proxy/api.koios.rest/...       Koios (Cardano)
    /proxy/api.cspr.cloud/...       CSPR.cloud (Casper, needs your free access token)

- Listens on your own computer only (127.0.0.1); nothing else can reach it.
- Forwards only to the hosts listed in ALLOWED_HOSTS, never anywhere else.
- Writes nothing to disk; API keys are passed straight through and never printed.

Run:  python3 start-classifier.py      Stop: Ctrl+C
"""
import http.server
import os
import ssl
import sys
import threading
import urllib.error
import urllib.request
import webbrowser

PORT = int(os.environ.get("PORT", "8765"))
HERE = os.path.dirname(os.path.abspath(__file__))
PAGE = "/evm-tx-classifier.html"
ALLOWED_HOSTS = {"api.blockscout.com", "btc1.trezor.io", "api.koios.rest", "api.cspr.cloud", "metadata.services.blockscout.com", "andromeda-explorer.metis.io", "api.blockberry.one"}
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) crypto-tx-classifier/2.0"


def ssl_context():
    try:
        import certifi  # present on many Python installs; falls back to system certs
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


CTX = ssl_context()


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=HERE, **kw)

    def _send(self, status, body, ctype="application/json"):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _target(self):
        path = self.path
        if path.startswith("/bsproxy/"):  # older page versions
            path = "/proxy/api.blockscout.com/" + path[len("/bsproxy/"):]
        if not path.startswith("/proxy/"):
            return None
        rest = path[len("/proxy/"):]
        host, _, tail = rest.partition("/")
        if host not in ALLOWED_HOSTS:
            return False
        return "https://%s/%s" % (host, tail)

    def do_GET(self):
        if self.path == "/helper-health":
            return self._send(200, b'{"ok":true,"version":2}')
        if self.path in ("/", ""):
            self.send_response(302)
            self.send_header("Location", PAGE)
            self.end_headers()
            return
        url = self._target()
        if url is None:
            return super().do_GET()
        return self.forward(url, None)

    def do_POST(self):
        url = self._target()
        if not url:
            return self._send(403, b'{"error":"host not allowed"}')
        length = int(self.headers.get("Content-Length") or 0)
        return self.forward(url, self.rfile.read(length) if length else b"")

    def forward(self, url, body):
        if url is False:
            return self._send(403, b'{"error":"host not allowed"}')
        headers = {"Accept": "application/json", "User-Agent": UA}
        if self.headers.get("Authorization"):  # e.g. the CSPR.cloud access token, passed straight through
            headers["Authorization"] = self.headers["Authorization"]
        if self.headers.get("X-Api-Key"):  # e.g. the Blockberry (Mina) key, passed straight through
            headers["X-Api-Key"] = self.headers["X-Api-Key"]
        if body is not None:
            headers["Content-Type"] = self.headers.get("Content-Type", "application/json")
        req = urllib.request.Request(url, data=body, headers=headers, method="POST" if body is not None else "GET")
        try:
            with urllib.request.urlopen(req, timeout=90, context=CTX) as r:
                status, data, ctype = r.status, r.read(), r.headers.get("Content-Type", "application/json")
        except urllib.error.HTTPError as e:
            status, data, ctype = e.code, e.read(), e.headers.get("Content-Type", "application/json")
        except Exception as e:  # network / SSL problems
            msg = str(e).replace('"', "'")
            status, data, ctype = 502, ('{"error":"helper could not reach the API: %s"}' % msg).encode(), "application/json"
        self._send(status, data, ctype)

    def log_message(self, fmt, *args):
        # One short line per request, without the query string (it may contain an API key).
        path = getattr(self, "path", None)
        if path is None:  # unreadable request, e.g. a browser trying https:// on this http-only address
            sys.stderr.write("Ignored an unreadable request (use http://, not https://, for this local address)\n")
            return
        sys.stderr.write("%s %s\n" % (args[1] if len(args) > 1 else "", path.split("?", 1)[0]))


def already_running(port):
    try:
        with urllib.request.urlopen("http://127.0.0.1:%d/helper-health" % port, timeout=2) as r:
            return b'"ok":true' in r.read()
    except Exception:
        return False


def start_server():
    # Use the usual port; if it is taken by something else, try the next few.
    for port in range(PORT, PORT + 10):
        try:
            return port, http.server.ThreadingHTTPServer(("127.0.0.1", port), Handler)
        except OSError:
            if already_running(port):
                link = "http://127.0.0.1:%d%s" % (port, PAGE)
                print("The classifier is already running at", link)
                if "--no-browser" not in sys.argv:
                    webbrowser.open(link)
                sys.exit(0)
    print("Could not find a free port between %d and %d." % (PORT, PORT + 9))
    sys.exit(1)


if __name__ == "__main__":
    port, server = start_server()
    link = "http://127.0.0.1:%d%s" % (port, PAGE)
    print("Crypto Transaction Classifier running at", link)
    print("Press Ctrl+C to stop.")
    if "--no-browser" not in sys.argv:
        threading.Timer(0.8, lambda: webbrowser.open(link)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
