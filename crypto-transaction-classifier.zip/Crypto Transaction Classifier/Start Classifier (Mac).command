#!/bin/bash
# Double-click to start the Crypto Transaction Classifier on a Mac.
# A Terminal window opens and the app opens in your web browser.
# Keep the Terminal window open while you use the app; close it (or press Ctrl+C) to stop.
cd "$(dirname "$0")" || exit 1
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is not installed."
  echo "Run this in Terminal to install Apple's free developer tools (includes Python 3):"
  echo "    xcode-select --install"
  echo "or download Python from https://www.python.org/downloads/ and try again."
  read -r -p "Press Enter to close..."
  exit 1
fi
python3 start-classifier.py
