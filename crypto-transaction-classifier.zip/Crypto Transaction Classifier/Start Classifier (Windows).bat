@echo off
rem Double-click to start the Crypto Transaction Classifier on Windows.
rem A black window opens and the app opens in your web browser.
rem Keep the window open while you use the app; close it to stop.
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 start-classifier.py
  goto end
)
where python >nul 2>nul
if %errorlevel%==0 (
  python start-classifier.py
  goto end
)
echo Python 3 is not installed.
echo Download it from https://www.python.org/downloads/
echo During setup, tick "Add python.exe to PATH", then double-click this file again.
:end
pause
